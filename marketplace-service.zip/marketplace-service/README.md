# marketplace-service

Microservice Spring Boot pour la marketplace (AFCON 2025).

Port: 8085

Endpoints:
- Products: POST/GET/PUT/DELETE /api/market/products
- Orders: POST /api/market/orders
