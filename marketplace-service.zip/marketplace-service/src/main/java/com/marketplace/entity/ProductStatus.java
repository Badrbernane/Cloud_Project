package com.marketplace.entity;

public enum ProductStatus {
    AVAILABLE,
    SOLD
}
