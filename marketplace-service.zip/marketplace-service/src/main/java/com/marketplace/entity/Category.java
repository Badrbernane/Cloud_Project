package com.marketplace.entity;

public enum Category {
    MAILLOTS,
    TICKETS,
    ACCESSOIRES,
    AUTRE
}
